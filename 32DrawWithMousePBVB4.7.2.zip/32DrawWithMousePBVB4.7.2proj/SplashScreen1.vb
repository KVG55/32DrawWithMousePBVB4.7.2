﻿Public NotInheritable Class SplashScreen1

    'TODO: легко использовать эту форму в качестве заставки. Это можно сделать на вкладке "Приложение"
    '  конструктора проектов (пункт "Свойства" в меню "Проект").
    Private ReadOnly Random As New Random


    Private Sub SplashScreen1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Установить текст диалога во время выполнения в соответствии с информацией о сборке приложения.  

        'TODO: настроить сведения о сборке приложения в области "Приложение" диалогового окна 
        '  свойств проекта (в меню "Проект").

        'Заголовок приложения
        If My.Application.Info.Title <> "" Then
            Label1.Text = My.Application.Info.Title
        Else
            'Если у приложения нет заголовка, использовать имя приложения без расширения
            ' Label2.Text = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)

        End If

        'Отформатировать информацию о версии с использованием в качестве строки формата текста,
        '  установленного для контроля версий во время разработки.  При необходимости это может использоваться для эффективной локализации.
        '  Информация о сборке и редакции может быть включена на основе следующего кода с заменой 
        '  текста, установленного для контроля версий во время разработки, на строку типа "Версия {0}.{1:00}.{2}.{3}".  Подробнее см.
        '  справку по String.Format().
        '
        '    Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor, My.Application.Info.Version.Build, My.Application.Info.Version.Revision)

        ' Label3.Text = System.String.Format(Label3.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor)
        'Label2.Visible = False

        Label2.Text = " Версия {1}.{0:00}.{1}.{0} "

        Label3.Visible = False
        'Информация об авторских правах
        Label4.Text = "֎ Copyright © WareZ VK Provider 2021 This program was made by Karavaev V.G."


        Timer1.Enabled = True


    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick


        BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label1.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label2.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label3.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label4.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))


    End Sub
End Class
