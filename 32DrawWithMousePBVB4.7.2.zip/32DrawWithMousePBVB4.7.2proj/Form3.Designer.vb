﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.КаскадToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СвернутьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РазвернутьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ВосстановитьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЗакрытьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.КонфиденциальностьToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СведенияToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutEasyMalbertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.Teal
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripButton3, Me.ToolStripButton4, Me.ToolStripTextBox1, Me.ToolStripTextBox2, Me.ToolStripTextBox3, Me.ToolStripButton6})
        resources.ApplyResources(Me.ToolStrip1, "ToolStrip1")
        Me.ToolStrip1.Name = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        resources.ApplyResources(Me.ToolStripButton1, "ToolStripButton1")
        Me.ToolStripButton1.Name = "ToolStripButton1"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        resources.ApplyResources(Me.ToolStripButton2, "ToolStripButton2")
        Me.ToolStripButton2.Name = "ToolStripButton2"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        resources.ApplyResources(Me.ToolStripButton3, "ToolStripButton3")
        Me.ToolStripButton3.Name = "ToolStripButton3"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        resources.ApplyResources(Me.ToolStripButton4, "ToolStripButton4")
        Me.ToolStripButton4.Name = "ToolStripButton4"
        '
        'ToolStripTextBox1
        '
        resources.ApplyResources(Me.ToolStripTextBox1, "ToolStripTextBox1")
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        '
        'ToolStripTextBox2
        '
        resources.ApplyResources(Me.ToolStripTextBox2, "ToolStripTextBox2")
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        '
        'ToolStripTextBox3
        '
        resources.ApplyResources(Me.ToolStripTextBox3, "ToolStripTextBox3")
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        resources.ApplyResources(Me.ToolStripButton6, "ToolStripButton6")
        Me.ToolStripButton6.Name = "ToolStripButton6"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.HotTrack
        resources.ApplyResources(Me.MenuStrip1, "MenuStrip1")
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DocumentToolStripMenuItem, Me.WindowToolStripMenuItem, Me.ServiceToolStripMenuItem})
        Me.MenuStrip1.MdiWindowListItem = Me.WindowToolStripMenuItem
        Me.MenuStrip1.Name = "MenuStrip1"
        '
        'DocumentToolStripMenuItem
        '
        Me.DocumentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.DocumentToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DocumentToolStripMenuItem.Name = "DocumentToolStripMenuItem"
        resources.ApplyResources(Me.DocumentToolStripMenuItem, "DocumentToolStripMenuItem")
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        resources.ApplyResources(Me.OpenToolStripMenuItem, "OpenToolStripMenuItem")
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        resources.ApplyResources(Me.ExitToolStripMenuItem, "ExitToolStripMenuItem")
        '
        'WindowToolStripMenuItem
        '
        Me.WindowToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.КаскадToolStripMenuItem, Me.СвернутьВсеToolStripMenuItem, Me.РазвернутьВсеToolStripMenuItem, Me.ВосстановитьВсеToolStripMenuItem, Me.ЗакрытьВсеToolStripMenuItem, Me.КонфиденциальностьToolStripMenuItem})
        Me.WindowToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.WindowToolStripMenuItem.Name = "WindowToolStripMenuItem"
        resources.ApplyResources(Me.WindowToolStripMenuItem, "WindowToolStripMenuItem")
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        resources.ApplyResources(Me.NewToolStripMenuItem, "NewToolStripMenuItem")
        '
        'КаскадToolStripMenuItem
        '
        Me.КаскадToolStripMenuItem.Name = "КаскадToolStripMenuItem"
        resources.ApplyResources(Me.КаскадToolStripMenuItem, "КаскадToolStripMenuItem")
        '
        'СвернутьВсеToolStripMenuItem
        '
        Me.СвернутьВсеToolStripMenuItem.Name = "СвернутьВсеToolStripMenuItem"
        resources.ApplyResources(Me.СвернутьВсеToolStripMenuItem, "СвернутьВсеToolStripMenuItem")
        '
        'РазвернутьВсеToolStripMenuItem
        '
        Me.РазвернутьВсеToolStripMenuItem.Name = "РазвернутьВсеToolStripMenuItem"
        resources.ApplyResources(Me.РазвернутьВсеToolStripMenuItem, "РазвернутьВсеToolStripMenuItem")
        '
        'ВосстановитьВсеToolStripMenuItem
        '
        Me.ВосстановитьВсеToolStripMenuItem.Name = "ВосстановитьВсеToolStripMenuItem"
        resources.ApplyResources(Me.ВосстановитьВсеToolStripMenuItem, "ВосстановитьВсеToolStripMenuItem")
        '
        'ЗакрытьВсеToolStripMenuItem
        '
        Me.ЗакрытьВсеToolStripMenuItem.Name = "ЗакрытьВсеToolStripMenuItem"
        resources.ApplyResources(Me.ЗакрытьВсеToolStripMenuItem, "ЗакрытьВсеToolStripMenuItem")
        '
        'КонфиденциальностьToolStripMenuItem
        '
        Me.КонфиденциальностьToolStripMenuItem.Name = "КонфиденциальностьToolStripMenuItem"
        resources.ApplyResources(Me.КонфиденциальностьToolStripMenuItem, "КонфиденциальностьToolStripMenuItem")
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.СведенияToolStripMenuItem, Me.AboutEasyMalbertToolStripMenuItem})
        Me.ServiceToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        resources.ApplyResources(Me.ServiceToolStripMenuItem, "ServiceToolStripMenuItem")
        '
        'СведенияToolStripMenuItem
        '
        Me.СведенияToolStripMenuItem.Name = "СведенияToolStripMenuItem"
        resources.ApplyResources(Me.СведенияToolStripMenuItem, "СведенияToolStripMenuItem")
        '
        'AboutEasyMalbertToolStripMenuItem
        '
        Me.AboutEasyMalbertToolStripMenuItem.Name = "AboutEasyMalbertToolStripMenuItem"
        resources.ApplyResources(Me.AboutEasyMalbertToolStripMenuItem, "AboutEasyMalbertToolStripMenuItem")
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'Form3
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form3"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox2 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As ToolStripTextBox
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DocumentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents КаскадToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents СвернутьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents РазвернутьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ВосстановитьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ЗакрытьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents КонфиденциальностьToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ServiceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents СведенияToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutEasyMalbertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents Timer1 As Timer
End Class
