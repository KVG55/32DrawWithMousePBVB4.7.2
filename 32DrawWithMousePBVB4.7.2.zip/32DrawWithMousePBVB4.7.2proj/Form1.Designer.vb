﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActSaveInFullScreenStateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Brush1ColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemOfCoordinateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextureBrushPictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GrBackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorMultGrToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FuzzyMltColorGrStartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControlVisibleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyFromScreenRBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RotateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HorizontalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerticalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PointsControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PointsControlRelaxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripTextBox4 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripComboBox2 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox3 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.NumericUpDown8 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown9 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton41 = New System.Windows.Forms.RadioButton()
        Me.RadioButton40 = New System.Windows.Forms.RadioButton()
        Me.RadioButton20 = New System.Windows.Forms.RadioButton()
        Me.RadioButton19 = New System.Windows.Forms.RadioButton()
        Me.RadioButton18 = New System.Windows.Forms.RadioButton()
        Me.RadioButton17 = New System.Windows.Forms.RadioButton()
        Me.RadioButton16 = New System.Windows.Forms.RadioButton()
        Me.RadioButton15 = New System.Windows.Forms.RadioButton()
        Me.RadioButton14 = New System.Windows.Forms.RadioButton()
        Me.RadioButton13 = New System.Windows.Forms.RadioButton()
        Me.RadioButton12 = New System.Windows.Forms.RadioButton()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.RadioButton22 = New System.Windows.Forms.RadioButton()
        Me.RadioButton21 = New System.Windows.Forms.RadioButton()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.RadioButton24 = New System.Windows.Forms.RadioButton()
        Me.RadioButton23 = New System.Windows.Forms.RadioButton()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.RadioButton26 = New System.Windows.Forms.RadioButton()
        Me.RadioButton25 = New System.Windows.Forms.RadioButton()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.RadioButton35 = New System.Windows.Forms.RadioButton()
        Me.RadioButton34 = New System.Windows.Forms.RadioButton()
        Me.RadioButton33 = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RadioButton32 = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.RadioButton31 = New System.Windows.Forms.RadioButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.NumericUpDown5 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton30 = New System.Windows.Forms.RadioButton()
        Me.RadioButton29 = New System.Windows.Forms.RadioButton()
        Me.RadioButton28 = New System.Windows.Forms.RadioButton()
        Me.RadioButton27 = New System.Windows.Forms.RadioButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.RadioButton39 = New System.Windows.Forms.RadioButton()
        Me.RadioButton38 = New System.Windows.Forms.RadioButton()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.RadioButton37 = New System.Windows.Forms.RadioButton()
        Me.RadioButton36 = New System.Windows.Forms.RadioButton()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.ComboBox32 = New System.Windows.Forms.ComboBox()
        Me.ComboBox31 = New System.Windows.Forms.ComboBox()
        Me.ComboBox30 = New System.Windows.Forms.ComboBox()
        Me.ComboBox29 = New System.Windows.Forms.ComboBox()
        Me.ComboBox28 = New System.Windows.Forms.ComboBox()
        Me.ComboBox27 = New System.Windows.Forms.ComboBox()
        Me.ComboBox26 = New System.Windows.Forms.ComboBox()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.ComboBox22 = New System.Windows.Forms.ComboBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.RadioButton42 = New System.Windows.Forms.RadioButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.RadioButton43 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown6 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown10 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown11 = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.RadioButton44 = New System.Windows.Forms.RadioButton()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.RadioButton45 = New System.Windows.Forms.RadioButton()
        Me.RadioButton46 = New System.Windows.Forms.RadioButton()
        Me.RadioButton47 = New System.Windows.Forms.RadioButton()
        Me.RadioButton48 = New System.Windows.Forms.RadioButton()
        Me.RadioButton49 = New System.Windows.Forms.RadioButton()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.DarkTurquoise
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.DecorToolStripMenuItem, Me.EditToolStripMenuItem, Me.FormatToolStripMenuItem, Me.ToolStripTextBox1, Me.ToolStripComboBox1, Me.ToolStripTextBox4})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1355, 27)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ExitToolStripMenuItem, Me.ActSaveInFullScreenStateToolStripMenuItem})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 23)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ActSaveInFullScreenStateToolStripMenuItem
        '
        Me.ActSaveInFullScreenStateToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.ActSaveInFullScreenStateToolStripMenuItem.Name = "ActSaveInFullScreenStateToolStripMenuItem"
        Me.ActSaveInFullScreenStateToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.ActSaveInFullScreenStateToolStripMenuItem.Text = "Act Save in full screen state"
        '
        'DecorToolStripMenuItem
        '
        Me.DecorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PenColorToolStripMenuItem, Me.Brush1ColorToolStripMenuItem, Me.SystemOfCoordinateToolStripMenuItem, Me.TextureBrushPictureToolStripMenuItem, Me.BackColorToolStripMenuItem, Me.GrBackColorToolStripMenuItem, Me.BackColorMultGrToolStripMenuItem, Me.FuzzyMltColorGrStartToolStripMenuItem, Me.ControlVisibleToolStripMenuItem, Me.AllScreenToolStripMenuItem})
        Me.DecorToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DecorToolStripMenuItem.Name = "DecorToolStripMenuItem"
        Me.DecorToolStripMenuItem.Size = New System.Drawing.Size(50, 23)
        Me.DecorToolStripMenuItem.Text = "Decor"
        '
        'PenColorToolStripMenuItem
        '
        Me.PenColorToolStripMenuItem.Name = "PenColorToolStripMenuItem"
        Me.PenColorToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.PenColorToolStripMenuItem.Text = "Pen Line Color"
        '
        'Brush1ColorToolStripMenuItem
        '
        Me.Brush1ColorToolStripMenuItem.Name = "Brush1ColorToolStripMenuItem"
        Me.Brush1ColorToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.Brush1ColorToolStripMenuItem.Text = "Brush1 Color"
        '
        'SystemOfCoordinateToolStripMenuItem
        '
        Me.SystemOfCoordinateToolStripMenuItem.Name = "SystemOfCoordinateToolStripMenuItem"
        Me.SystemOfCoordinateToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.SystemOfCoordinateToolStripMenuItem.Text = "System of coordinate"
        '
        'TextureBrushPictureToolStripMenuItem
        '
        Me.TextureBrushPictureToolStripMenuItem.Name = "TextureBrushPictureToolStripMenuItem"
        Me.TextureBrushPictureToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.TextureBrushPictureToolStripMenuItem.Text = "Texture Brush Picture"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.BackColorToolStripMenuItem.Text = "Back Color"
        '
        'GrBackColorToolStripMenuItem
        '
        Me.GrBackColorToolStripMenuItem.Name = "GrBackColorToolStripMenuItem"
        Me.GrBackColorToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.GrBackColorToolStripMenuItem.Text = "Gr Back Color"
        '
        'BackColorMultGrToolStripMenuItem
        '
        Me.BackColorMultGrToolStripMenuItem.Name = "BackColorMultGrToolStripMenuItem"
        Me.BackColorMultGrToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.BackColorMultGrToolStripMenuItem.Text = "Back Color Mult Gr"
        '
        'FuzzyMltColorGrStartToolStripMenuItem
        '
        Me.FuzzyMltColorGrStartToolStripMenuItem.Name = "FuzzyMltColorGrStartToolStripMenuItem"
        Me.FuzzyMltColorGrStartToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.FuzzyMltColorGrStartToolStripMenuItem.Text = "Fuzzy Mlt Color Gr Start"
        '
        'ControlVisibleToolStripMenuItem
        '
        Me.ControlVisibleToolStripMenuItem.Name = "ControlVisibleToolStripMenuItem"
        Me.ControlVisibleToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.ControlVisibleToolStripMenuItem.Text = "Control Visible"
        '
        'AllScreenToolStripMenuItem
        '
        Me.AllScreenToolStripMenuItem.Name = "AllScreenToolStripMenuItem"
        Me.AllScreenToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.AllScreenToolStripMenuItem.Text = "All screen"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.PastToolStripMenuItem, Me.CopyScreenToolStripMenuItem, Me.CopyFromScreenRBToolStripMenuItem, Me.RotateToolStripMenuItem, Me.ClipToolStripMenuItem})
        Me.EditToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 23)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PastToolStripMenuItem
        '
        Me.PastToolStripMenuItem.Name = "PastToolStripMenuItem"
        Me.PastToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.PastToolStripMenuItem.Text = "Past"
        '
        'CopyScreenToolStripMenuItem
        '
        Me.CopyScreenToolStripMenuItem.Name = "CopyScreenToolStripMenuItem"
        Me.CopyScreenToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.CopyScreenToolStripMenuItem.Text = "Copy Screen"
        '
        'CopyFromScreenRBToolStripMenuItem
        '
        Me.CopyFromScreenRBToolStripMenuItem.Name = "CopyFromScreenRBToolStripMenuItem"
        Me.CopyFromScreenRBToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.CopyFromScreenRBToolStripMenuItem.Text = "Copy and save from Screen RB"
        '
        'RotateToolStripMenuItem
        '
        Me.RotateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.ToolStripMenuItem9})
        Me.RotateToolStripMenuItem.Name = "RotateToolStripMenuItem"
        Me.RotateToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.RotateToolStripMenuItem.Text = "Rotate"
        Me.RotateToolStripMenuItem.ToolTipText = "Only for external Image." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Save the Image and then reopen" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "it for rotate and flip." &
    ""
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Enabled = False
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem7.Text = "90"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Enabled = False
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem8.Text = "180"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Enabled = False
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem9.Text = "270"
        '
        'ClipToolStripMenuItem
        '
        Me.ClipToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HorizontalToolStripMenuItem, Me.VerticalToolStripMenuItem})
        Me.ClipToolStripMenuItem.Name = "ClipToolStripMenuItem"
        Me.ClipToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ClipToolStripMenuItem.Text = "Flip"
        Me.ClipToolStripMenuItem.ToolTipText = "Only for external Image." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Save the Image and then" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "reopen it for rotate and flip." &
    ""
        '
        'HorizontalToolStripMenuItem
        '
        Me.HorizontalToolStripMenuItem.Enabled = False
        Me.HorizontalToolStripMenuItem.Name = "HorizontalToolStripMenuItem"
        Me.HorizontalToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.HorizontalToolStripMenuItem.Text = "Horizontal"
        '
        'VerticalToolStripMenuItem
        '
        Me.VerticalToolStripMenuItem.Enabled = False
        Me.VerticalToolStripMenuItem.Name = "VerticalToolStripMenuItem"
        Me.VerticalToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.VerticalToolStripMenuItem.Text = "Vertical"
        '
        'FormatToolStripMenuItem
        '
        Me.FormatToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PointsControlToolStripMenuItem, Me.PointsControlRelaxToolStripMenuItem})
        Me.FormatToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.FormatToolStripMenuItem.Name = "FormatToolStripMenuItem"
        Me.FormatToolStripMenuItem.Size = New System.Drawing.Size(57, 23)
        Me.FormatToolStripMenuItem.Text = "Format"
        '
        'PointsControlToolStripMenuItem
        '
        Me.PointsControlToolStripMenuItem.Name = "PointsControlToolStripMenuItem"
        Me.PointsControlToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.PointsControlToolStripMenuItem.Text = "Points Control"
        '
        'PointsControlRelaxToolStripMenuItem
        '
        Me.PointsControlRelaxToolStripMenuItem.Name = "PointsControlRelaxToolStripMenuItem"
        Me.PointsControlRelaxToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.PointsControlRelaxToolStripMenuItem.Text = "Points Control relax"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        Me.ToolStripTextBox1.Text = "Pen Line Width"
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(75, 23)
        Me.ToolStripComboBox1.Text = "1"
        '
        'ToolStripTextBox4
        '
        Me.ToolStripTextBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox4.Name = "ToolStripTextBox4"
        Me.ToolStripTextBox4.Size = New System.Drawing.Size(300, 23)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripLabel1, Me.ToolStripComboBox2, Me.ToolStripComboBox3, Me.ToolStripSeparator1, Me.ToolStripTextBox2, Me.ToolStripSeparator2, Me.ToolStripTextBox3, Me.ToolStripSeparator3, Me.ToolStripButton4, Me.ToolStripButton3, Me.ToolStripButton5, Me.ToolStripButton6})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 27)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1355, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.AutoSize = False
        Me.ToolStripButton1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(75, 22)
        Me.ToolStripButton1.Text = "Opacity -0%"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.AutoSize = False
        Me.ToolStripButton2.BackColor = System.Drawing.Color.Silver
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(75, 22)
        Me.ToolStripButton2.Text = "Opacity"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(243, 22)
        Me.ToolStripLabel1.Text = "Color Brush E /R , Brush Fill R/E, Gr Brush R/E"
        '
        'ToolStripComboBox2
        '
        Me.ToolStripComboBox2.Name = "ToolStripComboBox2"
        Me.ToolStripComboBox2.Size = New System.Drawing.Size(145, 25)
        '
        'ToolStripComboBox3
        '
        Me.ToolStripComboBox3.Name = "ToolStripComboBox3"
        Me.ToolStripComboBox3.Size = New System.Drawing.Size(145, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripTextBox2
        '
        Me.ToolStripTextBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        Me.ToolStripTextBox2.Size = New System.Drawing.Size(150, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripTextBox3
        '
        Me.ToolStripTextBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        Me.ToolStripTextBox3.Size = New System.Drawing.Size(150, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.BackColor = System.Drawing.Color.Green
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(35, 22)
        Me.ToolStripButton4.Text = "New"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.BackColor = System.Drawing.Color.Maroon
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton3.ForeColor = System.Drawing.SystemColors.Control
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(27, 22)
        Me.ToolStripButton3.Text = "Inv"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.BackColor = System.Drawing.Color.Navy
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton5.ForeColor = System.Drawing.Color.White
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(84, 22)
        Me.ToolStripButton5.Text = "Save in All Scr"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.BackColor = System.Drawing.Color.Silver
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(123, 22)
        Me.ToolStripButton6.Text = "System of coordinate"
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 102)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1355, 640)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = resources.GetString("OpenFileDialog1.Filter")
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "DWMPBVB19"
        Me.SaveFileDialog1.Filter = resources.GetString("SaveFileDialog1.Filter")
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl1.Location = New System.Drawing.Point(0, 52)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1355, 50)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.NumericUpDown4)
        Me.TabPage1.Controls.Add(Me.RadioButton10)
        Me.TabPage1.Controls.Add(Me.RadioButton9)
        Me.TabPage1.Controls.Add(Me.RadioButton8)
        Me.TabPage1.Controls.Add(Me.RadioButton7)
        Me.TabPage1.Controls.Add(Me.NumericUpDown3)
        Me.TabPage1.Controls.Add(Me.NumericUpDown2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.NumericUpDown1)
        Me.TabPage1.Controls.Add(Me.RadioButton6)
        Me.TabPage1.Controls.Add(Me.RadioButton5)
        Me.TabPage1.Controls.Add(Me.RadioButton4)
        Me.TabPage1.Controls.Add(Me.RadioButton3)
        Me.TabPage1.Controls.Add(Me.RadioButton2)
        Me.TabPage1.Controls.Add(Me.RadioButton1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Items"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.Location = New System.Drawing.Point(1299, 2)
        Me.NumericUpDown4.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown4.TabIndex = 14
        Me.NumericUpDown4.Value = New Decimal(New Integer() {90, 0, 0, 0})
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Location = New System.Drawing.Point(860, 1)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(81, 17)
        Me.RadioButton10.TabIndex = 13
        Me.RadioButton10.Text = "Brush Fill Ell"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(763, 2)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(93, 17)
        Me.RadioButton9.TabIndex = 12
        Me.RadioButton9.Text = "Brush Fill Rect"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'RadioButton8
        '
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Location = New System.Drawing.Point(672, 3)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(84, 17)
        Me.RadioButton8.TabIndex = 11
        Me.RadioButton8.Text = "Brush1 Rect"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(593, 3)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(72, 17)
        Me.RadioButton7.TabIndex = 10
        Me.RadioButton7.Text = "Brush1 Ell"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Location = New System.Drawing.Point(1253, 2)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown3.TabIndex = 9
        Me.NumericUpDown3.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(1206, 2)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown2.TabIndex = 8
        Me.NumericUpDown2.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1112, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "B Size W|H|Angle"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(1065, 2)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown1.TabIndex = 6
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(505, 4)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(83, 17)
        Me.RadioButton6.TabIndex = 5
        Me.RadioButton6.Text = "PenL Ellipse"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(398, 3)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(102, 17)
        Me.RadioButton5.TabIndex = 4
        Me.RadioButton5.Text = "PenL Rectangle"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(295, 3)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(97, 17)
        Me.RadioButton4.TabIndex = 3
        Me.RadioButton4.Text = "PenL Right line"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(184, 3)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(103, 17)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.Text = "PenL Some Line"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(101, 4)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(78, 17)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "PenL Lines"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(4, 4)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Stop/Change"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.NumericUpDown8)
        Me.TabPage2.Controls.Add(Me.NumericUpDown9)
        Me.TabPage2.Controls.Add(Me.RadioButton41)
        Me.TabPage2.Controls.Add(Me.RadioButton40)
        Me.TabPage2.Controls.Add(Me.RadioButton20)
        Me.TabPage2.Controls.Add(Me.RadioButton19)
        Me.TabPage2.Controls.Add(Me.RadioButton18)
        Me.TabPage2.Controls.Add(Me.RadioButton17)
        Me.TabPage2.Controls.Add(Me.RadioButton16)
        Me.TabPage2.Controls.Add(Me.RadioButton15)
        Me.TabPage2.Controls.Add(Me.RadioButton14)
        Me.TabPage2.Controls.Add(Me.RadioButton13)
        Me.TabPage2.Controls.Add(Me.RadioButton12)
        Me.TabPage2.Controls.Add(Me.RadioButton11)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Next Items"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'NumericUpDown8
        '
        Me.NumericUpDown8.Location = New System.Drawing.Point(760, 1)
        Me.NumericUpDown8.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown8.Name = "NumericUpDown8"
        Me.NumericUpDown8.Size = New System.Drawing.Size(42, 20)
        Me.NumericUpDown8.TabIndex = 14
        Me.NumericUpDown8.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'NumericUpDown9
        '
        Me.NumericUpDown9.Location = New System.Drawing.Point(808, 0)
        Me.NumericUpDown9.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown9.Name = "NumericUpDown9"
        Me.NumericUpDown9.Size = New System.Drawing.Size(42, 20)
        Me.NumericUpDown9.TabIndex = 13
        Me.NumericUpDown9.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'RadioButton41
        '
        Me.RadioButton41.AutoSize = True
        Me.RadioButton41.Location = New System.Drawing.Point(956, 2)
        Me.RadioButton41.Name = "RadioButton41"
        Me.RadioButton41.Size = New System.Drawing.Size(46, 17)
        Me.RadioButton41.TabIndex = 12
        Me.RadioButton41.TabStop = True
        Me.RadioButton41.Text = "Past"
        Me.ToolTip1.SetToolTip(Me.RadioButton41, resources.GetString("RadioButton41.ToolTip"))
        Me.RadioButton41.UseVisualStyleBackColor = True
        '
        'RadioButton40
        '
        Me.RadioButton40.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton40.AutoSize = True
        Me.RadioButton40.Location = New System.Drawing.Point(854, 0)
        Me.RadioButton40.Name = "RadioButton40"
        Me.RadioButton40.Size = New System.Drawing.Size(94, 23)
        Me.RadioButton40.TabIndex = 11
        Me.RadioButton40.TabStop = True
        Me.RadioButton40.Text = "Copy from creen"
        Me.ToolTip1.SetToolTip(Me.RadioButton40, resources.GetString("RadioButton40.ToolTip"))
        Me.RadioButton40.UseVisualStyleBackColor = True
        '
        'RadioButton20
        '
        Me.RadioButton20.AutoSize = True
        Me.RadioButton20.Location = New System.Drawing.Point(631, 3)
        Me.RadioButton20.Name = "RadioButton20"
        Me.RadioButton20.Size = New System.Drawing.Size(128, 17)
        Me.RadioButton20.TabIndex = 10
        Me.RadioButton20.TabStop = True
        Me.RadioButton20.Text = "Texture+GrBrushRect"
        Me.RadioButton20.UseVisualStyleBackColor = True
        '
        'RadioButton19
        '
        Me.RadioButton19.AutoSize = True
        Me.RadioButton19.Checked = True
        Me.RadioButton19.Location = New System.Drawing.Point(8, 3)
        Me.RadioButton19.Name = "RadioButton19"
        Me.RadioButton19.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton19.TabIndex = 9
        Me.RadioButton19.TabStop = True
        Me.RadioButton19.Text = "Stop/Change"
        Me.RadioButton19.UseVisualStyleBackColor = True
        '
        'RadioButton18
        '
        Me.RadioButton18.AutoSize = True
        Me.RadioButton18.Location = New System.Drawing.Point(1092, 3)
        Me.RadioButton18.Name = "RadioButton18"
        Me.RadioButton18.Size = New System.Drawing.Size(120, 17)
        Me.RadioButton18.TabIndex = 8
        Me.RadioButton18.Text = "Pen Line + Gr Brush"
        Me.RadioButton18.UseVisualStyleBackColor = True
        '
        'RadioButton17
        '
        Me.RadioButton17.AutoSize = True
        Me.RadioButton17.Location = New System.Drawing.Point(1010, 3)
        Me.RadioButton17.Name = "RadioButton17"
        Me.RadioButton17.Size = New System.Drawing.Size(75, 17)
        Me.RadioButton17.TabIndex = 7
        Me.RadioButton17.Text = "PenL +Br1"
        Me.RadioButton17.UseVisualStyleBackColor = True
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.Location = New System.Drawing.Point(1217, 1)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(126, 17)
        Me.RadioButton16.TabIndex = 6
        Me.RadioButton16.Text = "Rubber Thread Fill Ell"
        Me.ToolTip1.SetToolTip(Me.RadioButton16, "Draw fill Ellipse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "right in program" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "state of UI: " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " all screen." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.RadioButton16.UseVisualStyleBackColor = True
        '
        'RadioButton15
        '
        Me.RadioButton15.AutoSize = True
        Me.RadioButton15.Location = New System.Drawing.Point(543, 2)
        Me.RadioButton15.Name = "RadioButton15"
        Me.RadioButton15.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton15.TabIndex = 5
        Me.RadioButton15.Text = "TextureB Any"
        Me.RadioButton15.UseVisualStyleBackColor = True
        '
        'RadioButton14
        '
        Me.RadioButton14.AutoSize = True
        Me.RadioButton14.Location = New System.Drawing.Point(422, 3)
        Me.RadioButton14.Name = "RadioButton14"
        Me.RadioButton14.Size = New System.Drawing.Size(121, 17)
        Me.RadioButton14.TabIndex = 4
        Me.RadioButton14.Text = "Brush with Gr Ellipse"
        Me.RadioButton14.UseVisualStyleBackColor = True
        '
        'RadioButton13
        '
        Me.RadioButton13.AutoSize = True
        Me.RadioButton13.Location = New System.Drawing.Point(304, 3)
        Me.RadioButton13.Name = "RadioButton13"
        Me.RadioButton13.Size = New System.Drawing.Size(114, 17)
        Me.RadioButton13.TabIndex = 3
        Me.RadioButton13.Text = "Brush with Gr Rect"
        Me.RadioButton13.UseVisualStyleBackColor = True
        '
        'RadioButton12
        '
        Me.RadioButton12.AutoSize = True
        Me.RadioButton12.Location = New System.Drawing.Point(204, 3)
        Me.RadioButton12.Name = "RadioButton12"
        Me.RadioButton12.Size = New System.Drawing.Size(99, 17)
        Me.RadioButton12.TabIndex = 1
        Me.RadioButton12.Text = "Gr Brush Ellipse"
        Me.RadioButton12.UseVisualStyleBackColor = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Location = New System.Drawing.Point(108, 4)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(92, 17)
        Me.RadioButton11.TabIndex = 0
        Me.RadioButton11.Text = "Gr Brush Rect"
        Me.RadioButton11.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Controls.Add(Me.Button1)
        Me.TabPage3.Controls.Add(Me.TextBox1)
        Me.TabPage3.Controls.Add(Me.ComboBox3)
        Me.TabPage3.Controls.Add(Me.ComboBox2)
        Me.TabPage3.Controls.Add(Me.ComboBox1)
        Me.TabPage3.Controls.Add(Me.RadioButton22)
        Me.TabPage3.Controls.Add(Me.RadioButton21)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Next Items1.Text."
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(552, -1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "E-R"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(510, -1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(36, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "R-E"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(596, 1)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(748, 20)
        Me.TextBox1.TabIndex = 5
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(361, 1)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox3.TabIndex = 4
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(313, 1)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox2.TabIndex = 3
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Arial", "Bondoni MT", "Book Antiqua", "Bookman Old Style", "Calisto MT", "Castellar", "Century Gothic", "Century Schoolbook", "Comic Sans MS", "Courier", "Courier New", "Elephant", "Forte", "French Script MT", "Garamond", "Georgia", "Gigi", "Impact", "Kartika", "Latha", "Lucida Console", "Lucida Sans", "Mangal", "Marlett", "Microsoft Sans Serif", "MS Reference Sans Serif", "Palace Script MT", "Palatio Linotype", "Papurus", "Perpetua", "Rage Italic", "Rockwell", "Script MT Bold", "Symbol", "Tahoma", "Terminal", "Times New Roman", "Trebuchet MS", "Tunga", "Verdana", "Vrinda", "Webdings", "Wingdings"})
        Me.ComboBox1.Location = New System.Drawing.Point(165, 1)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'RadioButton22
        '
        Me.RadioButton22.AutoSize = True
        Me.RadioButton22.BackColor = System.Drawing.Color.White
        Me.RadioButton22.Location = New System.Drawing.Point(109, 4)
        Me.RadioButton22.Name = "RadioButton22"
        Me.RadioButton22.Size = New System.Drawing.Size(46, 17)
        Me.RadioButton22.TabIndex = 1
        Me.RadioButton22.TabStop = True
        Me.RadioButton22.Text = "Text"
        Me.RadioButton22.UseVisualStyleBackColor = False
        '
        'RadioButton21
        '
        Me.RadioButton21.AutoSize = True
        Me.RadioButton21.Checked = True
        Me.RadioButton21.Location = New System.Drawing.Point(9, 4)
        Me.RadioButton21.Name = "RadioButton21"
        Me.RadioButton21.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton21.TabIndex = 0
        Me.RadioButton21.TabStop = True
        Me.RadioButton21.Text = "Stop/Change"
        Me.RadioButton21.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.ComboBox8)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.ComboBox7)
        Me.TabPage4.Controls.Add(Me.ComboBox6)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.Label2)
        Me.TabPage4.Controls.Add(Me.ComboBox5)
        Me.TabPage4.Controls.Add(Me.RadioButton24)
        Me.TabPage4.Controls.Add(Me.RadioButton23)
        Me.TabPage4.Controls.Add(Me.ComboBox4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Next Item2. Coordinate."
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(775, 2)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox8.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(701, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Width pf pen"
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(650, 1)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox7.TabIndex = 7
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(599, 1)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox6.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(442, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(153, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Number of cells:  Width/Height"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(244, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Width/Height of cell"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(396, 1)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox5.TabIndex = 3
        '
        'RadioButton24
        '
        Me.RadioButton24.AutoSize = True
        Me.RadioButton24.Location = New System.Drawing.Point(104, 2)
        Me.RadioButton24.Name = "RadioButton24"
        Me.RadioButton24.Size = New System.Drawing.Size(127, 17)
        Me.RadioButton24.TabIndex = 2
        Me.RadioButton24.Text = "System Of Coordinate"
        Me.RadioButton24.UseVisualStyleBackColor = True
        '
        'RadioButton23
        '
        Me.RadioButton23.AutoSize = True
        Me.RadioButton23.Checked = True
        Me.RadioButton23.Location = New System.Drawing.Point(4, 3)
        Me.RadioButton23.Name = "RadioButton23"
        Me.RadioButton23.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton23.TabIndex = 1
        Me.RadioButton23.TabStop = True
        Me.RadioButton23.Text = "Stop/Change"
        Me.RadioButton23.UseVisualStyleBackColor = True
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(352, 1)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox4.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Controls.Add(Me.Label7)
        Me.TabPage5.Controls.Add(Me.Label6)
        Me.TabPage5.Controls.Add(Me.Label5)
        Me.TabPage5.Controls.Add(Me.ComboBox12)
        Me.TabPage5.Controls.Add(Me.ComboBox11)
        Me.TabPage5.Controls.Add(Me.ComboBox10)
        Me.TabPage5.Controls.Add(Me.RadioButton26)
        Me.TabPage5.Controls.Add(Me.RadioButton25)
        Me.TabPage5.Controls.Add(Me.ComboBox9)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Next Item3 Dah/Cap lines"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Teal
        Me.Label8.Location = New System.Drawing.Point(851, 4)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Dash Style"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Teal
        Me.Label7.Location = New System.Drawing.Point(643, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 13)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Dash Cap"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Teal
        Me.Label6.Location = New System.Drawing.Point(443, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "End Cap"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Teal
        Me.Label5.Location = New System.Drawing.Point(242, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Start Cap"
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(914, 0)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox12.TabIndex = 21
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(702, 0)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox11.TabIndex = 20
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(495, 0)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox10.TabIndex = 19
        '
        'RadioButton26
        '
        Me.RadioButton26.AutoSize = True
        Me.RadioButton26.Location = New System.Drawing.Point(103, 4)
        Me.RadioButton26.Name = "RadioButton26"
        Me.RadioButton26.Size = New System.Drawing.Size(129, 17)
        Me.RadioButton26.TabIndex = 18
        Me.RadioButton26.Text = "Dach/Cap Style Lines"
        Me.RadioButton26.UseVisualStyleBackColor = True
        '
        'RadioButton25
        '
        Me.RadioButton25.AutoSize = True
        Me.RadioButton25.Checked = True
        Me.RadioButton25.Location = New System.Drawing.Point(7, 3)
        Me.RadioButton25.Name = "RadioButton25"
        Me.RadioButton25.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton25.TabIndex = 17
        Me.RadioButton25.TabStop = True
        Me.RadioButton25.Text = "Stop/Change"
        Me.RadioButton25.UseVisualStyleBackColor = True
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(297, 1)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox9.TabIndex = 16
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.RadioButton35)
        Me.TabPage6.Controls.Add(Me.RadioButton34)
        Me.TabPage6.Controls.Add(Me.RadioButton33)
        Me.TabPage6.Controls.Add(Me.Label11)
        Me.TabPage6.Controls.Add(Me.RadioButton32)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.RadioButton31)
        Me.TabPage6.Controls.Add(Me.Label9)
        Me.TabPage6.Controls.Add(Me.NumericUpDown5)
        Me.TabPage6.Controls.Add(Me.RadioButton30)
        Me.TabPage6.Controls.Add(Me.RadioButton29)
        Me.TabPage6.Controls.Add(Me.RadioButton28)
        Me.TabPage6.Controls.Add(Me.RadioButton27)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Next Item4"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'RadioButton35
        '
        Me.RadioButton35.AutoSize = True
        Me.RadioButton35.Location = New System.Drawing.Point(1222, 4)
        Me.RadioButton35.Name = "RadioButton35"
        Me.RadioButton35.Size = New System.Drawing.Size(120, 17)
        Me.RadioButton35.TabIndex = 17
        Me.RadioButton35.TabStop = True
        Me.RadioButton35.Text = "Draw Fill Gr Polygon"
        Me.ToolTip1.SetToolTip(Me.RadioButton35, resources.GetString("RadioButton35.ToolTip"))
        Me.RadioButton35.UseVisualStyleBackColor = True
        '
        'RadioButton34
        '
        Me.RadioButton34.AutoSize = True
        Me.RadioButton34.Location = New System.Drawing.Point(1107, 2)
        Me.RadioButton34.Name = "RadioButton34"
        Me.RadioButton34.Size = New System.Drawing.Size(106, 17)
        Me.RadioButton34.TabIndex = 16
        Me.RadioButton34.TabStop = True
        Me.RadioButton34.Text = "Draw Fill Polygon"
        Me.RadioButton34.UseVisualStyleBackColor = True
        '
        'RadioButton33
        '
        Me.RadioButton33.AutoSize = True
        Me.RadioButton33.Location = New System.Drawing.Point(1005, 2)
        Me.RadioButton33.Name = "RadioButton33"
        Me.RadioButton33.Size = New System.Drawing.Size(94, 17)
        Me.RadioButton33.TabIndex = 15
        Me.RadioButton33.TabStop = True
        Me.RadioButton33.Text = "Deaw Polygon"
        Me.RadioButton33.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(857, 4)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(141, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Points of Gr 1;3||Color Brush "
        '
        'RadioButton32
        '
        Me.RadioButton32.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton32.AutoSize = True
        Me.RadioButton32.Location = New System.Drawing.Point(724, 0)
        Me.RadioButton32.Name = "RadioButton32"
        Me.RadioButton32.Size = New System.Drawing.Size(131, 23)
        Me.RadioButton32.TabIndex = 8
        Me.RadioButton32.TabStop = True
        Me.RadioButton32.Text = "Draw Fill Gr Close Curve"
        Me.ToolTip1.SetToolTip(Me.RadioButton32, "Draw Fill Close Curve " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "with color gradient" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "color at the Tool Strip" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Color Brush" &
        "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.RadioButton32.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(593, 4)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 13)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "Decor /Pen Lene/Brush1"
        '
        'RadioButton31
        '
        Me.RadioButton31.AutoSize = True
        Me.RadioButton31.Location = New System.Drawing.Point(463, 2)
        Me.RadioButton31.Name = "RadioButton31"
        Me.RadioButton31.Size = New System.Drawing.Size(125, 17)
        Me.RadioButton31.TabIndex = 6
        Me.RadioButton31.TabStop = True
        Me.RadioButton31.Text = "Draw Fill Close Curve"
        Me.RadioButton31.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(341, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Curve tention"
        '
        'NumericUpDown5
        '
        Me.NumericUpDown5.Location = New System.Drawing.Point(414, 2)
        Me.NumericUpDown5.Name = "NumericUpDown5"
        Me.NumericUpDown5.Size = New System.Drawing.Size(46, 20)
        Me.NumericUpDown5.TabIndex = 4
        '
        'RadioButton30
        '
        Me.RadioButton30.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton30.AutoSize = True
        Me.RadioButton30.Location = New System.Drawing.Point(237, 1)
        Me.RadioButton30.Name = "RadioButton30"
        Me.RadioButton30.Size = New System.Drawing.Size(102, 23)
        Me.RadioButton30.TabIndex = 3
        Me.RadioButton30.TabStop = True
        Me.RadioButton30.Text = "Draw Close Curve"
        Me.RadioButton30.UseVisualStyleBackColor = True
        '
        'RadioButton29
        '
        Me.RadioButton29.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton29.AutoSize = True
        Me.RadioButton29.Location = New System.Drawing.Point(162, 0)
        Me.RadioButton29.Name = "RadioButton29"
        Me.RadioButton29.Size = New System.Drawing.Size(73, 23)
        Me.RadioButton29.TabIndex = 2
        Me.RadioButton29.TabStop = True
        Me.RadioButton29.Text = "Draw Curve"
        Me.RadioButton29.UseVisualStyleBackColor = True
        '
        'RadioButton28
        '
        Me.RadioButton28.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton28.AutoSize = True
        Me.RadioButton28.Location = New System.Drawing.Point(87, 1)
        Me.RadioButton28.Name = "RadioButton28"
        Me.RadioButton28.Size = New System.Drawing.Size(74, 23)
        Me.RadioButton28.TabIndex = 1
        Me.RadioButton28.Text = "Draw Besier"
        Me.ToolTip1.SetToolTip(Me.RadioButton28, "Draw Besire Spline in five click" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Last to click ought to be double." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Make visible" &
        " control points." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "So invisible. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Main Menu - Format.")
        Me.RadioButton28.UseVisualStyleBackColor = True
        '
        'RadioButton27
        '
        Me.RadioButton27.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton27.AutoSize = True
        Me.RadioButton27.Checked = True
        Me.RadioButton27.Location = New System.Drawing.Point(4, 0)
        Me.RadioButton27.Name = "RadioButton27"
        Me.RadioButton27.Size = New System.Drawing.Size(81, 23)
        Me.RadioButton27.TabIndex = 0
        Me.RadioButton27.TabStop = True
        Me.RadioButton27.Text = "Stop/Change"
        Me.RadioButton27.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.RadioButton39)
        Me.TabPage7.Controls.Add(Me.RadioButton38)
        Me.TabPage7.Controls.Add(Me.ComboBox21)
        Me.TabPage7.Controls.Add(Me.ComboBox20)
        Me.TabPage7.Controls.Add(Me.ComboBox19)
        Me.TabPage7.Controls.Add(Me.ComboBox18)
        Me.TabPage7.Controls.Add(Me.ComboBox17)
        Me.TabPage7.Controls.Add(Me.ComboBox16)
        Me.TabPage7.Controls.Add(Me.ComboBox15)
        Me.TabPage7.Controls.Add(Me.ComboBox14)
        Me.TabPage7.Controls.Add(Me.ComboBox13)
        Me.TabPage7.Controls.Add(Me.RadioButton37)
        Me.TabPage7.Controls.Add(Me.RadioButton36)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Next Items5"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'RadioButton39
        '
        Me.RadioButton39.AutoSize = True
        Me.RadioButton39.Location = New System.Drawing.Point(186, 1)
        Me.RadioButton39.Name = "RadioButton39"
        Me.RadioButton39.Size = New System.Drawing.Size(55, 17)
        Me.RadioButton39.TabIndex = 13
        Me.RadioButton39.TabStop = True
        Me.RadioButton39.Text = "MPl10"
        Me.ToolTip1.SetToolTip(Me.RadioButton39, "Draw Multiple Fill" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gradient Color" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Polygon in 10 gradient" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "colors." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.RadioButton39.UseVisualStyleBackColor = True
        '
        'RadioButton38
        '
        Me.RadioButton38.AutoSize = True
        Me.RadioButton38.Location = New System.Drawing.Point(128, 2)
        Me.RadioButton38.Name = "RadioButton38"
        Me.RadioButton38.Size = New System.Drawing.Size(49, 17)
        Me.RadioButton38.TabIndex = 12
        Me.RadioButton38.TabStop = True
        Me.RadioButton38.Text = "MPl7"
        Me.ToolTip1.SetToolTip(Me.RadioButton38, "Draw Multiple Fill" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gradient Color" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Polygon in 7 gradient" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "colors." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.RadioButton38.UseVisualStyleBackColor = True
        '
        'ComboBox21
        '
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(1219, 1)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox21.TabIndex = 11
        '
        'ComboBox20
        '
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(1097, 1)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox20.TabIndex = 10
        '
        'ComboBox19
        '
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(976, 0)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox19.TabIndex = 9
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(854, 0)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox18.TabIndex = 8
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(732, 0)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox17.TabIndex = 7
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(611, 0)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox16.TabIndex = 6
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(490, 1)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox15.TabIndex = 5
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(369, 1)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox14.TabIndex = 4
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(247, 1)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox13.TabIndex = 3
        '
        'RadioButton37
        '
        Me.RadioButton37.AutoSize = True
        Me.RadioButton37.Location = New System.Drawing.Point(66, 2)
        Me.RadioButton37.Name = "RadioButton37"
        Me.RadioButton37.Size = New System.Drawing.Size(49, 17)
        Me.RadioButton37.TabIndex = 2
        Me.RadioButton37.TabStop = True
        Me.RadioButton37.Text = "MPl3"
        Me.ToolTip1.SetToolTip(Me.RadioButton37, "Draw Multiple Fill" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gradient Color" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Polygon in 3 gradient" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "colors")
        Me.RadioButton37.UseVisualStyleBackColor = True
        '
        'RadioButton36
        '
        Me.RadioButton36.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton36.AutoSize = True
        Me.RadioButton36.Checked = True
        Me.RadioButton36.Location = New System.Drawing.Point(1, 0)
        Me.RadioButton36.Name = "RadioButton36"
        Me.RadioButton36.Size = New System.Drawing.Size(57, 23)
        Me.RadioButton36.TabIndex = 1
        Me.RadioButton36.TabStop = True
        Me.RadioButton36.Text = "St/Chge"
        Me.RadioButton36.UseVisualStyleBackColor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.ComboBox32)
        Me.TabPage8.Controls.Add(Me.ComboBox31)
        Me.TabPage8.Controls.Add(Me.ComboBox30)
        Me.TabPage8.Controls.Add(Me.ComboBox29)
        Me.TabPage8.Controls.Add(Me.ComboBox28)
        Me.TabPage8.Controls.Add(Me.ComboBox27)
        Me.TabPage8.Controls.Add(Me.ComboBox26)
        Me.TabPage8.Controls.Add(Me.ComboBox25)
        Me.TabPage8.Controls.Add(Me.ComboBox24)
        Me.TabPage8.Controls.Add(Me.ComboBox23)
        Me.TabPage8.Controls.Add(Me.ComboBox22)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Next Items6. Nult Gr Back Color"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'ComboBox32
        '
        Me.ComboBox32.FormattingEnabled = True
        Me.ComboBox32.Location = New System.Drawing.Point(1217, 0)
        Me.ComboBox32.Name = "ComboBox32"
        Me.ComboBox32.Size = New System.Drawing.Size(122, 21)
        Me.ComboBox32.TabIndex = 11
        '
        'ComboBox31
        '
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Location = New System.Drawing.Point(1095, 0)
        Me.ComboBox31.Name = "ComboBox31"
        Me.ComboBox31.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox31.TabIndex = 10
        '
        'ComboBox30
        '
        Me.ComboBox30.FormattingEnabled = True
        Me.ComboBox30.Location = New System.Drawing.Point(972, 0)
        Me.ComboBox30.Name = "ComboBox30"
        Me.ComboBox30.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox30.TabIndex = 9
        '
        'ComboBox29
        '
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Location = New System.Drawing.Point(850, 0)
        Me.ComboBox29.Name = "ComboBox29"
        Me.ComboBox29.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox29.TabIndex = 8
        '
        'ComboBox28
        '
        Me.ComboBox28.FormattingEnabled = True
        Me.ComboBox28.Location = New System.Drawing.Point(728, 0)
        Me.ComboBox28.Name = "ComboBox28"
        Me.ComboBox28.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox28.TabIndex = 7
        '
        'ComboBox27
        '
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Location = New System.Drawing.Point(607, 0)
        Me.ComboBox27.Name = "ComboBox27"
        Me.ComboBox27.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox27.TabIndex = 6
        '
        'ComboBox26
        '
        Me.ComboBox26.FormattingEnabled = True
        Me.ComboBox26.Location = New System.Drawing.Point(486, 0)
        Me.ComboBox26.Name = "ComboBox26"
        Me.ComboBox26.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox26.TabIndex = 5
        '
        'ComboBox25
        '
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Location = New System.Drawing.Point(366, 0)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox25.TabIndex = 4
        '
        'ComboBox24
        '
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(245, 0)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox24.TabIndex = 3
        '
        'ComboBox23
        '
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Location = New System.Drawing.Point(123, 0)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox23.TabIndex = 2
        '
        'ComboBox22
        '
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Location = New System.Drawing.Point(2, 0)
        Me.ComboBox22.Name = "ComboBox22"
        Me.ComboBox22.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox22.TabIndex = 1
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.RadioButton44)
        Me.TabPage9.Controls.Add(Me.Label13)
        Me.TabPage9.Controls.Add(Me.Label12)
        Me.TabPage9.Controls.Add(Me.NumericUpDown11)
        Me.TabPage9.Controls.Add(Me.NumericUpDown10)
        Me.TabPage9.Controls.Add(Me.NumericUpDown7)
        Me.TabPage9.Controls.Add(Me.NumericUpDown6)
        Me.TabPage9.Controls.Add(Me.RadioButton43)
        Me.TabPage9.Controls.Add(Me.Button7)
        Me.TabPage9.Controls.Add(Me.Button6)
        Me.TabPage9.Controls.Add(Me.Button5)
        Me.TabPage9.Controls.Add(Me.Button4)
        Me.TabPage9.Controls.Add(Me.Button3)
        Me.TabPage9.Controls.Add(Me.RadioButton42)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Next Items7"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Enabled = False
        Me.Button7.Location = New System.Drawing.Point(1271, 2)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(73, 23)
        Me.Button7.TabIndex = 12
        Me.Button7.Text = "Flip Vertical"
        Me.ToolTip1.SetToolTip(Me.Button7, "only external pictures" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Enabled = False
        Me.Button6.Location = New System.Drawing.Point(1183, 1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(87, 23)
        Me.Button6.TabIndex = 11
        Me.Button6.Text = "Flip Horizontal"
        Me.ToolTip1.SetToolTip(Me.Button6, "only external pictures")
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Enabled = False
        Me.Button5.Location = New System.Drawing.Point(1100, 0)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 10
        Me.Button5.Text = "Rotate 270"
        Me.ToolTip1.SetToolTip(Me.Button5, "only external pictures" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Enabled = False
        Me.Button4.Location = New System.Drawing.Point(1023, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Rotate 180"
        Me.ToolTip1.SetToolTip(Me.Button4, "only external pictures")
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Location = New System.Drawing.Point(947, -1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "Rotate 90"
        Me.ToolTip1.SetToolTip(Me.Button3, "only external pictures")
        Me.Button3.UseVisualStyleBackColor = True
        '
        'RadioButton42
        '
        Me.RadioButton42.AutoSize = True
        Me.RadioButton42.Checked = True
        Me.RadioButton42.Location = New System.Drawing.Point(6, 2)
        Me.RadioButton42.Name = "RadioButton42"
        Me.RadioButton42.Size = New System.Drawing.Size(56, 17)
        Me.RadioButton42.TabIndex = 0
        Me.RadioButton42.TabStop = True
        Me.RadioButton42.Text = "Sp/Ch"
        Me.RadioButton42.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        '
        'RadioButton43
        '
        Me.RadioButton43.AutoSize = True
        Me.RadioButton43.Location = New System.Drawing.Point(62, 3)
        Me.RadioButton43.Name = "RadioButton43"
        Me.RadioButton43.Size = New System.Drawing.Size(118, 17)
        Me.RadioButton43.TabIndex = 13
        Me.RadioButton43.TabStop = True
        Me.RadioButton43.Text = "RB+Digital numbers" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.RadioButton43.UseVisualStyleBackColor = True
        '
        'NumericUpDown6
        '
        Me.NumericUpDown6.Location = New System.Drawing.Point(334, 1)
        Me.NumericUpDown6.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown6.Name = "NumericUpDown6"
        Me.NumericUpDown6.Size = New System.Drawing.Size(70, 20)
        Me.NumericUpDown6.TabIndex = 14
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.Location = New System.Drawing.Point(409, 2)
        Me.NumericUpDown7.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(70, 20)
        Me.NumericUpDown7.TabIndex = 15
        '
        'NumericUpDown10
        '
        Me.NumericUpDown10.Location = New System.Drawing.Point(561, 2)
        Me.NumericUpDown10.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown10.Name = "NumericUpDown10"
        Me.NumericUpDown10.Size = New System.Drawing.Size(70, 20)
        Me.NumericUpDown10.TabIndex = 16
        '
        'NumericUpDown11
        '
        Me.NumericUpDown11.Location = New System.Drawing.Point(634, 3)
        Me.NumericUpDown11.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown11.Name = "NumericUpDown11"
        Me.NumericUpDown11.Size = New System.Drawing.Size(70, 20)
        Me.NumericUpDown11.TabIndex = 17
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(180, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(154, 13)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Upper Left Point of sourse rect." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(483, 4)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(71, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Width/Height"
        '
        'RadioButton44
        '
        Me.RadioButton44.AutoSize = True
        Me.RadioButton44.Location = New System.Drawing.Point(713, 4)
        Me.RadioButton44.Name = "RadioButton44"
        Me.RadioButton44.Size = New System.Drawing.Size(208, 17)
        Me.RadioButton44.TabIndex = 20
        Me.RadioButton44.TabStop = True
        Me.RadioButton44.Text = "Past at click for mix colors of fragments"
        Me.ToolTip1.SetToolTip(Me.RadioButton44, resources.GetString("RadioButton44.ToolTip"))
        Me.RadioButton44.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.RadioButton49)
        Me.TabPage10.Controls.Add(Me.RadioButton48)
        Me.TabPage10.Controls.Add(Me.RadioButton47)
        Me.TabPage10.Controls.Add(Me.RadioButton46)
        Me.TabPage10.Controls.Add(Me.RadioButton45)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(1347, 24)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Next Items8"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'RadioButton45
        '
        Me.RadioButton45.AutoSize = True
        Me.RadioButton45.Checked = True
        Me.RadioButton45.Location = New System.Drawing.Point(5, 4)
        Me.RadioButton45.Name = "RadioButton45"
        Me.RadioButton45.Size = New System.Drawing.Size(89, 17)
        Me.RadioButton45.TabIndex = 0
        Me.RadioButton45.TabStop = True
        Me.RadioButton45.Text = "Stop/Change"
        Me.RadioButton45.UseVisualStyleBackColor = True
        '
        'RadioButton46
        '
        Me.RadioButton46.AutoSize = True
        Me.RadioButton46.Location = New System.Drawing.Point(106, 3)
        Me.RadioButton46.Name = "RadioButton46"
        Me.RadioButton46.Size = New System.Drawing.Size(120, 17)
        Me.RadioButton46.TabIndex = 1
        Me.RadioButton46.Text = "RB Draw Rectangle" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.RadioButton46.UseVisualStyleBackColor = True
        '
        'RadioButton47
        '
        Me.RadioButton47.AutoSize = True
        Me.RadioButton47.Location = New System.Drawing.Point(235, 3)
        Me.RadioButton47.Name = "RadioButton47"
        Me.RadioButton47.Size = New System.Drawing.Size(101, 17)
        Me.RadioButton47.TabIndex = 7
        Me.RadioButton47.Text = "RB Draw Ellipse"
        Me.ToolTip1.SetToolTip(Me.RadioButton47, "Draw fill Ellipse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "right in program" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "state of UI: " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " all screen." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.RadioButton47.UseVisualStyleBackColor = True
        '
        'RadioButton48
        '
        Me.RadioButton48.AutoSize = True
        Me.RadioButton48.Location = New System.Drawing.Point(346, 4)
        Me.RadioButton48.Name = "RadioButton48"
        Me.RadioButton48.Size = New System.Drawing.Size(116, 17)
        Me.RadioButton48.TabIndex = 8
        Me.RadioButton48.Text = "RB Draw Fill Ellipse"
        Me.RadioButton48.UseVisualStyleBackColor = True
        '
        'RadioButton49
        '
        Me.RadioButton49.AutoSize = True
        Me.RadioButton49.Location = New System.Drawing.Point(475, 4)
        Me.RadioButton49.Name = "RadioButton49"
        Me.RadioButton49.Size = New System.Drawing.Size(135, 17)
        Me.RadioButton49.TabIndex = 9
        Me.RadioButton49.Text = "RB Draw Fill Rectangle"
        Me.RadioButton49.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1355, 742)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Draw With Mouse in Pb"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DecorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PenColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PastToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripComboBox1 As ToolStripComboBox
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents RadioButton5 As RadioButton
    Friend WithEvents RadioButton6 As RadioButton
    Friend WithEvents RadioButton7 As RadioButton
    Friend WithEvents NumericUpDown3 As NumericUpDown
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label1 As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents ToolStripComboBox2 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox3 As ToolStripComboBox
    Friend WithEvents Brush1ColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RadioButton8 As RadioButton
    Friend WithEvents RadioButton10 As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents NumericUpDown4 As NumericUpDown
    Friend WithEvents RadioButton12 As RadioButton
    Friend WithEvents RadioButton11 As RadioButton
    Friend WithEvents RadioButton14 As RadioButton
    Friend WithEvents RadioButton13 As RadioButton
    Friend WithEvents RadioButton16 As RadioButton
    Friend WithEvents RadioButton15 As RadioButton
    Friend WithEvents GrBackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox2 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As ToolStripTextBox
    Friend WithEvents RadioButton17 As RadioButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents RadioButton18 As RadioButton
    Friend WithEvents RadioButton19 As RadioButton
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents ControlVisibleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextureBrushPictureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox4 As ToolStripTextBox
    Friend WithEvents RadioButton20 As RadioButton
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents RadioButton22 As RadioButton
    Friend WithEvents RadioButton21 As RadioButton
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ActSaveInFullScreenStateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripButton5 As ToolStripButton
    Friend WithEvents SystemOfCoordinateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents RadioButton24 As RadioButton
    Friend WithEvents RadioButton23 As RadioButton
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents RadioButton26 As RadioButton
    Friend WithEvents RadioButton25 As RadioButton
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents RotateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents ClipToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HorizontalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerticalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RadioButton28 As RadioButton
    Friend WithEvents RadioButton27 As RadioButton
    Friend WithEvents FormatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PointsControlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PointsControlRelaxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents RadioButton29 As RadioButton
    Friend WithEvents RadioButton30 As RadioButton
    Friend WithEvents Label9 As Label
    Friend WithEvents NumericUpDown5 As NumericUpDown
    Friend WithEvents RadioButton31 As RadioButton
    Friend WithEvents RadioButton32 As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents RadioButton33 As RadioButton
    Friend WithEvents RadioButton34 As RadioButton
    Friend WithEvents RadioButton35 As RadioButton
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents RadioButton36 As RadioButton
    Friend WithEvents ComboBox21 As ComboBox
    Friend WithEvents ComboBox20 As ComboBox
    Friend WithEvents ComboBox19 As ComboBox
    Friend WithEvents ComboBox18 As ComboBox
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents ComboBox16 As ComboBox
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents RadioButton37 As RadioButton
    Friend WithEvents RadioButton39 As RadioButton
    Friend WithEvents RadioButton38 As RadioButton
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents ComboBox32 As ComboBox
    Friend WithEvents ComboBox31 As ComboBox
    Friend WithEvents ComboBox30 As ComboBox
    Friend WithEvents ComboBox29 As ComboBox
    Friend WithEvents ComboBox28 As ComboBox
    Friend WithEvents ComboBox27 As ComboBox
    Friend WithEvents ComboBox26 As ComboBox
    Friend WithEvents ComboBox25 As ComboBox
    Friend WithEvents ComboBox24 As ComboBox
    Friend WithEvents ComboBox23 As ComboBox
    Friend WithEvents ComboBox22 As ComboBox
    Friend WithEvents BackColorMultGrToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer2 As Timer
    Friend WithEvents FuzzyMltColorGrStartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyFromScreenRBToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RadioButton40 As RadioButton
    Friend WithEvents RadioButton41 As RadioButton
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents RadioButton42 As RadioButton
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents NumericUpDown8 As NumericUpDown
    Friend WithEvents NumericUpDown9 As NumericUpDown
    Friend WithEvents RadioButton43 As RadioButton
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents NumericUpDown11 As NumericUpDown
    Friend WithEvents NumericUpDown10 As NumericUpDown
    Friend WithEvents NumericUpDown7 As NumericUpDown
    Friend WithEvents NumericUpDown6 As NumericUpDown
    Friend WithEvents RadioButton44 As RadioButton
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents RadioButton49 As RadioButton
    Friend WithEvents RadioButton48 As RadioButton
    Friend WithEvents RadioButton47 As RadioButton
    Friend WithEvents RadioButton46 As RadioButton
    Friend WithEvents RadioButton45 As RadioButton
End Class
