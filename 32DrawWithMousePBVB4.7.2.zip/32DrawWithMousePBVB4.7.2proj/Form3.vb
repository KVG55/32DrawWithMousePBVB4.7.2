﻿'©Виталий Караваев.

Imports System.Security.Cryptography
Public Class Form3
    Private ReadOnly PasswordText As String

    Private ReadOnly m_Random As New Random


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            AutoScroll = False
            ' сокрытие кнопок конфиденциальности
            ToolStrip1.Visible = False

        Catch ex As Exception

        End Try

    End Sub


    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click

        Try

            If (String.IsNullOrEmpty(ToolStripTextBox1.Text()) = True) Then
                MsgBox("Введите пароль")
            Else
                Dim password As String = InputBox("Введите пароль:")

                If Not (Equals(ToolStripTextBox1.Text(), password) = True) Then
                    MsgBox("Неправильный пароль, введите действующий.")
                Else
                    'Создание объекта дочерней формы.
                    'Присвоение объекту значения выполнения.
                    'Пересчет дочерних форм в главной строке формы.
                    Dim NMdChd As New Form1 With {
                        .MdiParent = Me,
                        .Text = " " + MdiChildren.Length.ToString()
                    }
                    Text = " Draw With Mouse PB  -  +" + MdiChildren.Length.ToString()

                    'Вывод на экран дочерней формы.
                    NMdChd.Show()



                End If
            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try


    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        Try

            If (String.IsNullOrEmpty(ToolStripTextBox1.Text()) = True) Then
                MsgBox("Введите пароль")
            Else

                If Not (ToolStripTextBox1.Text() = "**e98e6d69ce2-a338-2be9-f866-dae1fb1d7faf62S1Y<Z") Then
                    MsgBox("Неправильный пароль, введите действующий.")
                Else

                    Dim password As String = InputBox("Введите пароль:")

                    If Not (Equals(ToolStripTextBox1.Text(), password) = True) Then
                        MsgBox("Неправильный пароль, введите действующий.")
                    Else
                        Dim NMdChd As New Form1 With {
                            .MdiParent = Me,
                            .Text = " " + MdiChildren.Length.ToString()
                        }
                        Text = " Рисование -  +" + MdiChildren.Length.ToString()

                        NMdChd.Show()

                    End If
                End If
            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub



    Private Sub КаскадToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles КаскадToolStripMenuItem.Click, ЗакрытьВсеToolStripMenuItem.Click

        If sender.ToString Is "Каскад" Then
            LayoutMdi(MdiLayout.Cascade)
        ElseIf sender.ToString Is "Закрыть все" Then
            ' Close all child forms of the parent.
            For Each ChildForm As Form In Me.MdiChildren
                ChildForm.Close()
            Next
        End If
    End Sub

    Private Sub СвернутьВсеToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles СвернутьВсеToolStripMenuItem.Click
        Try
            For Each NewMDIChild As Form In MdiChildren
                NewMDIChild.WindowState = FormWindowState.Minimized
            Next NewMDIChild
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub РазвернутьВсеToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles РазвернутьВсеToolStripMenuItem.Click
        Try

            For Each NewMDIChild As Form In MdiChildren
                NewMDIChild.WindowState = FormWindowState.Maximized
            Next NewMDIChild
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub ВосстановитьВсеToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ВосстановитьВсеToolStripMenuItem.Click
        Try
            For Each NewMDIChild As Form In MdiChildren
                NewMDIChild.WindowState = FormWindowState.Normal
            Next NewMDIChild
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub



    Public NotInheritable Class Simple3Des
        ' Объявление и декларация переменной экземпляра класса крипто провайдера
        Private ReadOnly TriDsCrySP As New TripleDESCryptoServiceProvider
        ' функция кэша ключа
        Private Function TruncateHash(key As String, length As Integer) As Byte()
            ' создание переменной объекта криптографии
            Dim sha1 As New SHA1CryptoServiceProvider

            ' Hash the key.
            Dim keyBytes() As Byte = System.Text.Encoding.GetEncoding(1251).GetBytes(key)
            Dim hash() As Byte = sha1.ComputeHash(keyBytes)

            ' Truncate or pad the hash.
            ReDim Preserve hash(length - 1)
            Return hash
        End Function
        ' процедура инициализации крипто провайдера
        Sub New(key As String)
            ' Initialize the crypto provider.
            TriDsCrySP.Key = TruncateHash(key, TriDsCrySP.KeySize \ 8)
            TriDsCrySP.IV = TruncateHash("", TriDsCrySP.BlockSize \ 8)
        End Sub

        ' функция конвертации текста, кодирования-шифрования
        Public Function EncryptData(PasswordText As String) As String

            ' Convert the PasswordText   string to a byte array.
            Dim plaintextBytes() As Byte =
                System.Text.Encoding.GetEncoding(1251).GetBytes(PasswordText)

            ' Create the stream.
            Dim ms As New IO.MemoryStream
            ' Create the encoder to write to the stream.
            Dim encStream As New CryptoStream(ms,
                TriDsCrySP.CreateEncryptor(),
                CryptoStreamMode.Write)

            ' Use the crypto stream to write the byte array to the stream.
            encStream.Write(plaintextBytes, 0, plaintextBytes.Length)
            encStream.FlushFinalBlock()

            ' Convert the encrypted stream to a printable string.
            Return Convert.ToBase64String(ms.ToArray)

        End Function
        ' функция дешифровки текста, декодирования
        Public Function DecryptData(encryptedtext As String) As String
            Try
                ' Convert the encrypted text string to a byte array.
                Dim encryptedBytes() As Byte = Convert.FromBase64String(encryptedtext)

                ' Create the stream.
                Dim ms As New IO.MemoryStream
                ' Create the decoder to write to the stream.
                Dim decStream As New CryptoStream(ms,
                    TriDsCrySP.CreateDecryptor(),
                    CryptoStreamMode.Write)

                ' Use the crypto stream to write the byte array to the stream.
                decStream.Write(encryptedBytes, 0, encryptedBytes.Length)
                decStream.FlushFinalBlock()

                ' Convert the PasswordText   stream to a string.
                Return System.Text.Encoding.GetEncoding(1251).GetString(ms.ToArray)
            Catch ex As Exception

            End Try
            Return Nothing
        End Function

    End Class

    '''<summary>Determines if a password is sufficiently complex.</summary>
    ''' <param name="pwd">Password to validate</param>
    ''' <param name="minLength">Minimum number of password characters.</param>
    ''' <param name="numUpper">Minimum number of uppercase characters.</param>
    ''' <param name="numLower">Minimum number of lowercase characters.</param>
    ''' <param name="numNumbers">Minimum number of numeric characters.</param>
    ''' <param name="numSpecial">Minimum number of special characters.</param>
    ''' <returns>True if the password is sufficiently complex.</returns>
    Function ValidatePassword(pwd As String,
        Optional minLength As Integer = 8,
        Optional numUpper As Integer = 2,
        Optional numLower As Integer = 2,
        Optional numNumbers As Integer = 2,
        Optional numSpecial As Integer = 2) As Boolean

        ' Replace [A-Z] with \p{Lu}, to allow for Unicode uppercase letters.
        Dim upper As New Text.RegularExpressions.Regex("[A-Z]")
        Dim lower As New Text.RegularExpressions.Regex("[a-z]")
        Dim number As New Text.RegularExpressions.Regex("[0-9]")
        ' Special is "none of the above".
        Dim special As New Text.RegularExpressions.Regex("[^a-zA-Z0-9]")

        ' Check the length.
        If Len(pwd) < minLength Then Return False
        ' Check for minimum number of occurrences.
        If upper.Matches(pwd).Count < numUpper Then Return False
        If lower.Matches(pwd).Count < numLower Then Return False
        If number.Matches(pwd).Count < numNumbers Then Return False
        If special.Matches(pwd).Count < numSpecial Then Return False

        ' Passed all checks.
        Return True
    End Function




    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click

        Try
            ' A GUID is essentially a 16-byte (or 128-bit) number.
            ' So we must create a byte array with 16 byte elements.
            Dim RandomBytes(15) As Byte

            ' Fill the byte array with random bytes.
            Dim Random As New RNGCryptoServiceProvider()
            Random.GetBytes(RandomBytes)

            ' Create the GUID using these bytes.
            Dim MyGuid As New Guid(RandomBytes)

            ToolStripTextBox2.Text() = MyGuid.ToString()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click

        Try
            If (String.IsNullOrEmpty(ToolStripTextBox3.Text()) = True) Then
                MsgBox("Введите пароль")
            Else
                Dim PasswordText As String = ToolStripTextBox2.Text()


                Dim password As String = ToolStripTextBox3.Text()

                Dim wrapper As New Simple3Des(password)
                Dim cipherText As String = wrapper.EncryptData(PasswordText)

                ToolStripTextBox2.Text() = ""
                ToolStripTextBox3.Text() = ""

                SaveFileDialog1.Filter = "Text|*.TXT|All Files|*.*"
                SaveFileDialog1.FileName = "Имя файла"
                If SaveFileDialog1.ShowDialog = DialogResult.OK Then
                    My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, text:=cipherText, append:=False, encoding:=System.Text.Encoding.GetEncoding(1251))
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try


    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        Try
            If (String.IsNullOrEmpty(ToolStripTextBox3.Text()) = True) Then
                MsgBox("Введите пароль в последнее окно, справа.")
            Else
                Dim password As String = ToolStripTextBox3.Text()

                If OpenFileDialog1.ShowDialog = DialogResult.OK Then
                    '"Консеквент", декларирует переменную как строку
                    Dim cipherText As String
                    'Присваивает ей значение выполнения, открывает и читает текстовый файл в кодировке 1251 
                    ' с выбранным именем в выбранном директории, на любом диске
                    cipherText = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName, System.Text.Encoding.GetEncoding(1251))
                    'Выводит контент в обогащенное окно на форму. 

                    Dim wrapper As New Simple3Des(password)

                    ' DecryptData throws if the wrong password is used.

                    Dim PasswordText As String = wrapper.DecryptData(cipherText)

                    ToolStripTextBox1.Text() = PasswordText
                    ToolStripTextBox3.Text() = ""

                End If
            End If
        Catch ex As CryptographicException
            MsgBox("Данные не могут быть выведены с этим паролем.")
        End Try

    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        Try
            Dim password1 As String
            password1 = ToolStripTextBox2.Text()

            MsgBox(password1 & " сложный: " & ValidatePassword(password1))
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub


    Private Sub КонфиденциальностьToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles КонфиденциальностьToolStripMenuItem.Click
        Try
            If КонфиденциальностьToolStripMenuItem.Text() = "Конфиденциальность" Then

                'открытие кнопок конфиденциальности

                ToolStrip1.Visible = True
                КонфиденциальностьToolStripMenuItem.Text() = "Сокрыть"
            Else

                ToolStrip1.Visible = False
                КонфиденциальностьToolStripMenuItem.Text() = "Конфиденциальность"

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs) Handles ToolStripButton6.Click
        Try
            If ToolStripButton6.Text = "Start" Then
                Timer1.Enabled = True
                ToolStripButton6.Text = "Stop"
            Else
                ToolStripButton6.Text = "Start"

                Timer1.Enabled = False

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub


    Sub Создать1()
        Try

            Dim RandomBytes(15) As Byte


            Dim Random As New RNGCryptoServiceProvider()
            Random.GetBytes(RandomBytes)

            ' Create the GUID using these bytes.
            Dim MyGuid As New Guid(RandomBytes)

            Dim Text(10) As String
            Dim Number As Short
            Text(0) = "Ab"
            Text(1) = "HT"
            Text(2) = "Fr"
            Text(3) = "p["
            Text(4) = "*e"
            Text(5) = "%M"
            Text(6) = "@z"
            Text(7) = "%C"
            Text(8) = "u!"
            Text(9) = "Dl"
            Text(10) = "P^"
            Randomize()
            Number = CShort(Int((Rnd() * 11) + 1) - 1)
            Dim a As String = Text(Number)


            Dim Text11(10) As String
            Dim Number1 As Short
            Text11(0) = "b"
            Text11(1) = "c"
            Text11(2) = "q"
            Text11(3) = "k"
            Text11(4) = "0w"
            Text11(5) = "(;"
            Text11(6) = "':"
            Text11(7) = ".>"
            Text11(8) = "<"
            Text11(9) = ">"
            Text11(10) = "y"
            Randomize()
            Number1 = CShort(Int((Rnd() * 11) + 1) - 1)
            Dim b As String = Text11(Number1)



            Dim Text0(10) As String
            Dim Number10 As Short
            Text0(0) = "bl"
            Text0(1) = "cq"
            Text0(2) = "q,"
            Text0(3) = "k["
            Text0(4) = "01"
            Text0(5) = "*("
            Text0(6) = ")!"
            Text0(7) = "x7"
            Text0(8) = "ks"
            Text0(9) = "ef"
            Text0(10) = "le"
            Randomize()
            Number10 = CShort(Int((Rnd() * 11) + 1) - 1)
            Dim c As String = Text0(Number10)





            Dim Text01(10) As String
            Dim Number101 As Short
            Text01(0) = "5A"
            Text01(1) = "a0"
            Text01(2) = "3m"
            Text01(3) = "N8"
            Text01(4) = "4:"
            Text01(5) = ";#"
            Text01(6) = ">>"
            Text01(7) = "__"
            Text01(8) = ",1"
            Text01(9) = "V%"
            Text01(10) = "$?"
            Randomize()
            Number101 = CShort(Int((Rnd() * 11) + 1) - 1)
            Dim d As String = Text01(Number101)



            ToolStripTextBox2.Text() = a & m_Random.Next(100) & MyGuid.ToString() & m_Random.Next(100) & c & m_Random.Next(500) & d



        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()

    End Sub

    Private Sub СведенияToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles СведенияToolStripMenuItem.Click
        Try
            Dim Fr2 As Form2 = Form2
            Fr2.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub AboutEasyMalbertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutEasyMalbertToolStripMenuItem.Click
        Try
            Dim ABbx As AboutBox1 = AboutBox1
            ABbx.Show()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub ServiceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ServiceToolStripMenuItem.Click
        Try

            If ServiceToolStripMenuItem.Text = "Service" Then

                ServiceToolStripMenuItem.ForeColor = Color.Black
                ServiceToolStripMenuItem.Text = "Service OK"
            Else
                ServiceToolStripMenuItem.ForeColor = Color.White
                ServiceToolStripMenuItem.Text = "Service"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mistake", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub WindowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WindowToolStripMenuItem.Click
        Try

            If WindowToolStripMenuItem.Text = "Window" Then

                WindowToolStripMenuItem.ForeColor = Color.Black
                WindowToolStripMenuItem.Text = "Window OK"
            Else
                WindowToolStripMenuItem.ForeColor = Color.White
                WindowToolStripMenuItem.Text = "Window"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mistake", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub DocumentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DocumentToolStripMenuItem.Click
        Try

            If DocumentToolStripMenuItem.Text = "Document" Then

                DocumentToolStripMenuItem.ForeColor = Color.Black
                DocumentToolStripMenuItem.Text = "Document OK"
            Else
                DocumentToolStripMenuItem.ForeColor = Color.White
                DocumentToolStripMenuItem.Text = "Document"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Mistake", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub
End Class